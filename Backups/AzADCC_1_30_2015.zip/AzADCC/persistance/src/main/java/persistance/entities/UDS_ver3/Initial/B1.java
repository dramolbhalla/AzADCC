package persistance.entities.UDS_ver3.Initial;

public class B1 {

}
