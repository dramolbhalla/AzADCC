package persistance.entities.Clinics;

public class Clinic {

}
