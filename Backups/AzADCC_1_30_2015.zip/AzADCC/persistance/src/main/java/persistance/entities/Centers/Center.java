package persistance.entities.Centers;

public class Center {

}
