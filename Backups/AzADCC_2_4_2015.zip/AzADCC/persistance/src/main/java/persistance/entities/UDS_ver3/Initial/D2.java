/**
 * @author Amol Bhalla
 */

package persistance.entities.UDS_ver3.Initial;

public class D2 {
	int uid;
	int sid;
	String userId;
	String userInitial;
	String subjectId;
	String formMo;
	String formDy;
	String formYr;
	int visitNum;
	String visitType;
	int d2;
	int cancer;
	int cancsite;
	int diabet;
	int myoinf;
	int conghrt;
	int afibrill;
	int hypert;
	int angina;
	int hypchol;
	int vb12def;
	int thydis;
	int arth;
	int artype;
	String artypex;
	int artupex;
	int artloex;
	int artspin;
	int artunkn;
	int urineinc;
	int bowlic;
	int sleepap;
	int remdis;
	int hyposom;
	int sleepoth;
	int sleeptx;
	int angiocp;
	int angiopci;
	int pacemake;
	int hvalve;
	int antienc;
	String antiencx;
	int othcond;
	String othcondx;
}
