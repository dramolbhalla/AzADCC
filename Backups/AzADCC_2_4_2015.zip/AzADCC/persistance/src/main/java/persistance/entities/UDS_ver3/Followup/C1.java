/**
 * @author Amol Bhalla
 */

package persistance.entities.UDS_ver3.Followup;

public class C1 {
	int uid;
	int sid;
	String userId;
	String userInitial;
	String subjectId;
	String formMo;
	String formDy;
	String formYr;
	int visitNum;
	String visitType;
	int c1;
	int mmsecomp;
	int mmsereas;
	int mmseloc;
	int mmselan;
	String mmselanx;
	int mmsevis;
	int mmsehear;
	int mmseorda;
	int mmseorlo;
	int pentagon;
	int mmse;
	int npsycloc;
	int npsylan;
	String npsylanx;
	int logimo;
	int logiday;
	int logiyr;
	int logiprev;
	int logimem;
	int udsbentc;
	int digif;
	int digiflen;
	int digib;
	int digiblen;
	int animals;
	int veg;
	int traila;
	int trailarr;
	int trailali;
	int trailb;
	int trailbrr;
	int trailbli;
	int memunits;
	int memtime;
	int udsbentd;
	int udsbenrs;
	int boston;
	int udsverfc;
	int udsverfn;
	int udsvernf;
	int udsverlc;
	int udsverlr;
	int udsverln;
	int udsvertn;
	int udsverte;
	int udsverti;
	int cogstat;
}
