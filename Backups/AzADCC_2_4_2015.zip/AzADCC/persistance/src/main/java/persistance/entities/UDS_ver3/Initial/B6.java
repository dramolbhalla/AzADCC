/**
 * @author Amol Bhalla
 */

package persistance.entities.UDS_ver3.Initial;

public class B6 {
	int uid;
	int sid;
	String userId;
	String userInitial;
	String subjectId;
	String formMo;
	String formDy;
	String formYr;
	int visitNum;
	String visitType;
	int b6;
	int nogds;
	int satis;
	int dropact;
	int empty;
	int bored;
	int spirits;
	int afraid;
	int happy;
	int helpless;
	int stayhome;
	int memprob;
	int wondrful;
	int wrthless;
	int energy;
	int hopeless;
	int better;
	int gds;
	

}
