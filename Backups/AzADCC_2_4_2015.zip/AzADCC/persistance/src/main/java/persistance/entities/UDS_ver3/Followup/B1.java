/**
 * @author Amol Bhalla
 */

package persistance.entities.UDS_ver3.Followup;

public class B1 {
	int uid;
	int sid;
	String userId;
	String userInitial;
	String subjectId;
	String formMo;
	String formDy;
	String formYr;
	int visitNum;
	String visitType;
	int b1;
	int height;
	int wieght;
	int bpsys;
	int bpdias;
	int hrate;
	int vision;
	int viscorr;
	int viswcorr;
	int hearing;
	int hearaid;
	int hearwaid;
}
