/**
 * @author Amol Bhalla
 */

package persistance.entities.UDS_ver3.Initial;

public class B8 {
	int uid;
	int sid;
	String userId;
	String userInitial;
	String subjectId;
	String formMo;
	String formDy;
	String formYr;
	int visitNum;
	String visitType;
	int b8;
	int normexam;
	int parksign;
	int resttrl;
	int resttrr;
	int slowingl;
	int slowingr;
	int rigidl;
	int rigidr;
	int brady;
	int parkgait;
	int postinst;
	int cvdsigns;
	int cortdef;
	int sivdfind;
	int cvdmotl;
	int cvdmotr;
	int cortvisl;
	int cortvisr;
	int somatl;
	int somatr;
	int postcort;
	int pspcbs;
	int eyepsp;
	int dyspsp;
	int axialpsp;
	int gaitpsp;
	int apraxsp;
	int apraxl;
	int apraxr;
	int cortsenl;
	int cortsenr;
	int ataxl;
	int ataxr;
	int alienlml;
	int alienlmr;
	int dystonl;
	int dystonr;
	int myocllt;
	int myoclrt;
	int alsfind;
	int gaitnph;
	int othneur;
	String othneurx;
}
