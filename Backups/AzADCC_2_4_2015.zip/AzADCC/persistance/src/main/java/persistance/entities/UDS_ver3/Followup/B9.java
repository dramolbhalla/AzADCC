/**
 * @author Amol Bhalla
 */

package persistance.entities.UDS_ver3.Followup;

public class B9 {
	int uid;
	int sid;
	String userId;
	String userInitial;
	String subjectId;
	String formMo;
	String formDy;
	String formYr;
	int visitNum;
	String visitType;
	int b9;
	int decsub;
	int decin;
	int decclcog;
	int cogmem;
	int cogori;
	int cogjudg;
	int coglang;
	int cogvis;
	int cogattn;
	int cogfluc;
	int cogflago;
	int cogothr;
	String cogothrx;
	int cogfpred;
	String cogfprex;
	int cogmode;
	String cogmodex;
	int decage;
	int decclbe;
	int beapathy;
	int bedep;
	int bevhall;
	int bevwell;
	int bevhago;
	int beahall;
	int bedel;
	int bedisin;
	int beirrit;
	int beagit;
	int beperch;
	int berem;
	int beremago;
	int beanx;
	int beothr;
	String beothrx;
	int befpred;
	String befpredx;
	int bemode;
	String bemodex;
	int beage;
	int decclmot;
	int mogait;
	int mofalls;
	int motrem;
	int moslow;
	int mofrst;
	int momode;
	String momodex;
	int momopark;
	int parkage;
	int momoals;
	int alsage;
	int moage;
	int course;
	int frstchg;
	int lbdeval;
	int ftldeval;
}
