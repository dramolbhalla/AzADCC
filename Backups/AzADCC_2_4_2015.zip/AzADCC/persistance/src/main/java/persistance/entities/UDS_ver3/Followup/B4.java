/**
 * @author Amol Bhalla
 */

package persistance.entities.UDS_ver3.Followup;

public class B4 {
	int uid;
	int sid;
	String userId;
	String userInitial;
	String subjectId;
	String formMo;
	String formDy;
	String formYr;
	int visitNum;
	String visitType;
	int b4;
	int memory;
	int orient;
	int judgment;
	int commun;
	int homehobb;
	int perscare;
	int cdrsum;
	int cdrglob;
	int comport;
	int cdrlang;
}
