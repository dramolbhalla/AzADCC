/**
 * @author Amol Bhalla
 */

package persistance.entities.UDS_ver3.Initial;

public class A2 {
	int uid;
	int sid;
	String userId;
	String userInitial;
	String subjectId;
	String formMo;
	String formDy;
	String formYr;
	int visitNum;
	String visitType;
	int a2;
	int inbirmo;
	int inbiryr;
	int insex;
	int inhisp;
	int inhispor;
	String inhispox;
	int inrace;
	String inracex;
	int inrasec;
	String inrasecx;
	int inrater;
	String inraterx;
	int ineduc;
	int inrelto;
	int inknown;
	int inlivwth;
	int invisits;
	int incalls;
	int inrely;

}
