/**
 * @author Amol Bhalla
 */

package persistance.entities.UDS_ver3.Followup;

public class B7 {
	int uid;
	int sid;
	String userId;
	String userInitial;
	String subjectId;
	String formMo;
	String formDy;
	String formYr;
	int visitNum;
	String visitType;
	int b7;
	int bills;
	int taxes;
	int shopping;
	int games;
	int stove;
	int mealprep;
	int events;
	int payattn;
	int remdates;
	int travel;
}
