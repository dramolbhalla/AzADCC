package persistance.entities.UDS_ver3.Initial;

public class C2 {
	int uid;
	int sid;
	String userId;
	String subjectId;

}
