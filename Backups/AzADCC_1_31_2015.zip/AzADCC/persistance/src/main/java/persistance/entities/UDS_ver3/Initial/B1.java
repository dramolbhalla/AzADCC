package persistance.entities.UDS_ver3.Initial;

public class B1 {
	int uid;
	int sid;
	String userId;
	String subjectId;
	int height;
	int wieght;
	int bpsys;
	int bpdias;
	int hrate;
	int vision;
	int viscorr;
	int viswcorr;
	int hearing;
	int hearaid;
	int hearwaid;
}
