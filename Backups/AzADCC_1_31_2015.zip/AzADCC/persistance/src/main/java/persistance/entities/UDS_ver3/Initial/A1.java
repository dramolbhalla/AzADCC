package persistance.entities.UDS_ver3.Initial;

public class A1 {
	int uid;
	int sid;
	String userId;
	String subjectId;
	int reason;
	int refersc;
	int learned;
	int prestat;
	int prespart;
	int sourcenw;
	int birthmo;
	int birthyr;
	int sex;
	int hispanic;
	int hispor;
	String hisporx;
	int race;
	String racex;
	int racesec;
	String racesecx;
	int raceter;
	String raceterx;
	int primlang;
	String primlanx;
	int educ;
	int maristat;
	int livsitua;
	int independ;
	int residenc;
	String zip;
	int handed;
}
