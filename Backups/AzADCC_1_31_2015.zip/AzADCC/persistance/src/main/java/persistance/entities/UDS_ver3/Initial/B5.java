package persistance.entities.UDS_ver3.Initial;

public class B5 {
	int uid;
	int sid;
	String userId;
	String subjectId;
	int npiqinf;
	String npiqinfx;
	int del;
	int delsev;
	int hall;
	int hallsev;
	int agit;
	int agitsev;
	int depd;
	int depdsev;
	int anx;
	int anxsev;
	int elat;
	int elatsev;
	int apa;
	int apasev;
	int disn;
	int disnsev;
	int irr;
	int irrsev;
	int mot;
	int motsev;
	int nite;
	int nitesev;
	int app;
	int appsev;

}
