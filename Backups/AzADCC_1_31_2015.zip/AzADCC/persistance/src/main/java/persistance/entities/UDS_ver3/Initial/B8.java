package persistance.entities.UDS_ver3.Initial;

public class B8 {
	int uid;
	int sid;
	String userId;
	String subjectId;
}
