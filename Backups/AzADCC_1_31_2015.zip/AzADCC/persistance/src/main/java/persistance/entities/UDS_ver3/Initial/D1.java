package persistance.entities.UDS_ver3.Initial;

public class D1 {
	int uid;
	int sid;
	String userId;
	String subjectId;

}
