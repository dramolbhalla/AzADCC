package persistance.entities.UDS_ver3.Initial;

public class B6 {
	int uid;
	int sid;
	String userId;
	String subjectId;
	int nogds;
	int satis;
	int dropact;
	int empty;
	int bored;
	int spirits;
	int afraid;
	int happy;
	int helpless;
	int stayhome;
	int memprob;
	int wondrful;
	int wrthless;
	int energy;
	int hopeless;
	int better;
	int gds;
	

}
