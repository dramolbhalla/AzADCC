package persistance.entities.UDS_ver3.Initial;

public class Header {
	
	int uid;
	int sid;
	String userId;
	String subjectId;
	char packet;
	String formid;
	int formver;
	int adcid;
	String ptid;
	int visitmo;
	int visitday;
	int visityr;
	int visitnum;
	String initials;
}
