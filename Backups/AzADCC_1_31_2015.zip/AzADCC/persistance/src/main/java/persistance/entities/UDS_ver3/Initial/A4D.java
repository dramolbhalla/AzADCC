package persistance.entities.UDS_ver3.Initial;

public class A4D {
	int uid;
	int sid;
	String userId;
	String subjectId;
	String drugid;

}
