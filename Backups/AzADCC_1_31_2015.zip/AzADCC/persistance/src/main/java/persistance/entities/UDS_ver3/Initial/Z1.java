package persistance.entities.UDS_ver3.Initial;

public class Z1 {
	
	int uid;
	int sid;
	String userId;
	String subjectId;
	int a2sub;
	int a2not;
	String a2comm;
	int a3sub;
	int a3not;
	String a3comm;
	int a4sub;
	int a4not;
	String a4comm;
	int b1sub;
	int b1not;
	String b1comm;
	int b5sub;
	int b5not;
	String b5comm;
	int b6sub;
	int b6not;
	String B6Comm;
	int b7sub;
	int b7not;
	String b7comm;
}
