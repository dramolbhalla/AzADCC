package persistance.entities.UDS_ver3.Initial;

public class B4 {
	int uid;
	int sid;
	String userId;
	String subjectId;
	int memory;
	int orient;
	int judgment;
	int commun;
	int homehobb;
	int perscare;
	int cdrsum;
	int cdrglob;
	int comport;
	int cdrlang;
}
